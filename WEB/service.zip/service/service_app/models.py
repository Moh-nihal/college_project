from django.db import models

# Create your models here.


class login_table(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    type=models.CharField(max_length=100)
class expert_table(models.Model):
    LOGIN=models.ForeignKey(login_table,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.BigIntegerField()
    email=models.EmailField()
    phone=models.BigIntegerField()

class service_center_table(models.Model):
    LOGIN = models.ForeignKey(login_table, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    details = models.CharField(max_length=500)
    email = models.EmailField()
    phone = models.BigIntegerField()
    photo=models.FileField()
    lati=models.FloatField()
    longi=models.FloatField()

class user_table(models.Model):
    LOGIN = models.ForeignKey(login_table, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    pin = models.BigIntegerField()
    email = models.EmailField()
    phone = models.BigIntegerField()

class complaint_table(models.Model):
    USER=models.ForeignKey(user_table, on_delete=models.CASCADE)
    complaint = models.CharField(max_length=500)
    date=models.DateField()
    reply = models.CharField(max_length=100)

class feedback_table(models.Model):
    USER = models.ForeignKey(user_table, on_delete=models.CASCADE)
    feedback = models.CharField(max_length=500)
    date = models.DateField()
    rating=models.FloatField()

class database_table(models.Model):
    question = models.CharField(max_length=500)
    answer = models.CharField(max_length=500)

class doubts_table(models.Model):
    LOGIN = models.ForeignKey(login_table, on_delete=models.CASCADE)
    EXPERT = models.ForeignKey(expert_table, on_delete=models.CASCADE)
    doubts= models.CharField(max_length=500)
    date = models.DateField()
    reply = models.CharField(max_length=500)


class tips_table(models.Model):
    EXPERT=models.ForeignKey(expert_table, on_delete=models.CASCADE)
    tips=models.CharField(max_length=500)
    details = models.CharField(max_length=500)

class services_table(models.Model):
    SERVICE_CENTER=models.ForeignKey(service_center_table, on_delete=models.CASCADE)
    service_name = models.CharField(max_length=500)
    details= models.CharField(max_length=500)

class service_request_table(models.Model):
    USER=models.ForeignKey(user_table,on_delete=models.CASCADE)
    SERVICE_CENTER=models.ForeignKey(services_table,on_delete=models.CASCADE)
    request=models.CharField(max_length=500)
    status=models.CharField(max_length=500)
    date=models.DateField()

class bill_table(models.Model):
    request_id=models.ForeignKey(service_request_table,on_delete=models.CASCADE)
    amount=models.BigIntegerField()
    date=models.DateField()
    status=models.CharField(max_length=500)

class payment_table(models.Model):
    USER=models.ForeignKey(user_table,on_delete=models.CASCADE)
    BILL=models.ForeignKey(bill_table,on_delete=models.CASCADE)
    amount = models.BigIntegerField()
    date = models.DateField()
    status=models.CharField(max_length=500)

class chat_bot(models.Model):
    USER=models.ForeignKey(user_table,on_delete=models.CASCADE)
    question=models.CharField(max_length=500)
    answer = models.CharField(max_length=1000)
    Date=models.DateField()











