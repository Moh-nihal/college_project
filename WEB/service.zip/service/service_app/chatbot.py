def chatbot_main(question):

    import openai

    openai.api_key = "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"
    system = [{"role": "system",
               "content": "You are chatbot who enjoys python programming."}]
    user = [{"role": "user", "content": "brief introduction?"}]
    chat = []

    response = openai.ChatCompletion.create(
        messages = system +[{"role": "user", "content": question}],
        model="gpt-3.5-turbo", top_p=0.5, stream=True)
    reply = ""
    for delta in response:
        if not delta['choices'][0]['finish_reason']:
            word = delta['choices'][0]['delta']['content']
            reply += word
    print(reply)
    return reply
