import json
from datetime import datetime

from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
from service_app.models import *


def login(request):
    return render(request,"admin/loginindex.html")


def logout(request):
    auth.logout(request)
    return render(request,"admin/loginindex.html")


def loginpost(request):
    username=request.POST['textfield']
    password=request.POST['textfield2']
    var=login_table.objects.get(username=username,password=password)
    if var.type == 'admin':
        ob=auth.authenticate(username='admin',password='admin')
        if ob is not None:
            auth.login(request,ob)

        return HttpResponse('''<script>alert("Login Successfull");window.location="/admin_home#about"</script>''')
    elif var.type == 'expert':
        request.session['lid'] = var.id
        ob = auth.authenticate(username='admin', password='admin')
        if ob is not None:
            auth.login(request, ob)
        return HttpResponse('''<script>alert("Welcome to Expert Home");window.location="/expert_home#about"</script>''')
    elif var.type == 'service provider':
        request.session['lid'] = var.id
        ob = auth.authenticate(username='admin', password='admin')
        if ob is not None:
            auth.login(request, ob)

        return HttpResponse('''<script>alert("Welcome to service provider home");window.location="/service_home#about"</script>''')
    else:
        return HttpResponse('''<script>alert("Invalid Username Or Password");window.location="/"</script>''')









@login_required(login_url='/')
def accept_reject_sp(request):
    ob=service_center_table.objects.all()
    return render(request,"admin/accept reject sp.html",{'val':ob})




@login_required(login_url='/')
def add_expert(request):
    return render(request,"admin/add expert.html")
@login_required(login_url='/')
def addexpertpost(request):
    name=request.POST['textfield']
    place=request.POST['textfield2']
    post=request.POST['textfield3']
    pin=request.POST['textfield4']
    email=request.POST['textfield5']
    phone=request.POST['textfield6']
    username=request.POST['textfield7']
    password=request.POST['textfield8']

    ob=login_table()
    ob.username=username
    ob.password=password
    ob.type='expert'
    ob.save()

    obj=expert_table()
    obj.LOGIN=ob
    obj.name=name
    obj.place=place
    obj.post=post
    obj.pin=pin
    obj.email=email
    obj.phone=phone
    obj.save()
    return HttpResponse('''<script>alert("Add Success");window.location="/manage_expert#about"</script>''')





@login_required(login_url='/')

def admin_home(request):
    return render(request,"admin/adminindex.html")



@login_required(login_url='/')

def block_unblock_sp(request):
    ob=service_center_table.objects.all()
    return render(request,"admin/block unblock sp.html",{'val':ob})

@login_required(login_url='/')
def accept_sp(request, id):
    ob=login_table.objects.get(id=id)
    ob.type="service provider"
    ob.save()
    return HttpResponse('''<script>alert("Accepted");window.location="/accept_reject_sp#about"</script>''')


@login_required(login_url='/')
def reject_sp(request,id):
    ob=login_table.objects.get(id=id)
    ob.type="Rejected"
    ob.save()
    return HttpResponse('''<script>alert("Rejected");window.location="/accept_reject_sp#about"</script>''')




@login_required(login_url='/')
def block_sp(request, id):
    ob=login_table.objects.get(id=id)
    ob.type="blocked"
    ob.save()
    return HttpResponse('''<script>alert("blocked");window.location="/block_unblock_sp#about"</script>''')
#
# def block_sp(request, id):
#     ob=login_table.objects.get(id=id)
#     ob.type="blocked"
#     ob.save()
#     return HttpResponse('''<script>alert("blocked");window.location="/block_unblock_sp"</script>''')
#
# def block_sp(request, id):
#     ob=login_table.objects.get(id=id)
#     ob.type="blocked"
#     ob.save()
#     return HttpResponse('''<script>alert("blocked");window.location="/block_unblock_sp"</script>''')



@login_required(login_url='/')
def unblock_sp(request, id):
    ob=login_table.objects.get(id=id)
    ob.type="service provider"
    ob.save()
    return HttpResponse('''<script>alert("unblocked");window.location="/block_unblock_sp#about"</script>''')



@login_required(login_url='/')
def edit_expert(request, id):
    request.session['exp_id'] = id
    ob = expert_table.objects.get(id=id)
    return render(request,"admin/edit expert.html", {'val': ob})




@login_required(login_url='/')
def delete_expert(request, id):
    ob=expert_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("Deleted");window.location="/manage_expert#about"</script>''')



@login_required(login_url='/')
def delete_tips(request,id):
    ob=tips_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("Deleted");window.location="/manage_tips#about"</script>''')



@login_required(login_url='/')
def delete_dataset(request,id):
    ob=database_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("Deleted");window.location="/manage_data_set#about"</script>''')



@login_required(login_url='/')
def editexpertpost(request):
    name=request.POST['textfield']
    place=request.POST['textfield2']
    post=request.POST['textfield3']
    pin=request.POST['textfield4']
    email=request.POST['textfield5']
    phone=request.POST['textfield6']
    ob = expert_table.objects.get(id=request.session['exp_id'])
    ob.name = name
    ob.place=place
    ob.post=post
    ob.pin=pin
    ob.email=email
    ob.phone=phone
    ob.save()
    return HttpResponse('''<script>alert("Edit Success");window.location="/manage_expert#about"</script>''')



@login_required(login_url='/')
def manage_expert(request):
    ob = expert_table.objects.all()
    return render(request,"admin/manage expert.html",{'val':ob})

@login_required(login_url='/')
def exp_search(request):
    nm=request.POST['textfield']
    ob = expert_table.objects.filter(name__icontains=nm)
    return render(request, "admin/manage expert.html", {'val': ob})

@login_required(login_url='/')
def sp_search(request):
    nm=request.POST['textfield']
    ob = service_center_table.objects.filter(name__icontains=nm)
    return render(request,"admin/accept reject sp.html",{'val':ob})

@login_required(login_url='/')
def user_search(request):
    date=request.POST['textfield']
    ob = complaint_table.objects.filter(date=date)
    return render(request,"admin/view complaints.html",{'val':ob})


@login_required(login_url='/')
def doubt_search(request):
    date=request.POST['textfield']
    ob = doubts_table.objects.filter(date=date)
    return render(request,"expert/view doubt.html",{'val':ob})

@login_required(login_url='/')
def send_reply(request,id):
    request.session['com_id']=id
    return render(request,"admin/send reply.html")


@login_required(login_url='/')
def send_reply_post(request):
    rep=request.POST['textfield']
    ob=complaint_table.objects.get(id=request.session['com_id'])
    ob.reply=rep
    ob.save()
    return HttpResponse('''<script>alert("sended Success");window.location="/view_complaints#about"</script>''')

def doubt_reply(request,id):
    request.session['dob_id']=id
    return render(request,"expert/send doubtreply.html")

@login_required(login_url='/')
def doubt_reply_post(request):
    rep=request.POST['textfield']
    ob=doubts_table.objects.get(id=request.session['dob_id'])
    ob.reply=rep
    ob.save()
    return HttpResponse('''<script>alert("sended Success");window.location="/view_doubt#about"</script>''')





@login_required(login_url='/')
def view_complaints(request):
    ob=complaint_table.objects.all()
    return render(request,"admin/view complaints.html",{'val':ob})

@login_required(login_url='/')
def view_feedback_rating(request):
    ob=feedback_table.objects.all()
    return render(request,"admin/view feedback rating.html",{'val':ob})



@login_required(login_url='/')
def Add_data_set(request):
    return render(request,"expert/Add data set.html")

@login_required(login_url='/')
def adddatasetpost (request):
    question=request.POST['textfield']
    answer=request.POST['textfield2']
    ob=database_table()
    ob.question=question
    ob.answer=answer
    ob.save()
    return HttpResponse('''<script>alert("Add Success");window.location="/manage_data_set#about"</script>''')




@login_required(login_url='/')
def Add_tips(request):
    return render(request,"expert/Add tips.html")



@login_required(login_url='/')
def expert_home(request):
    return render(request,"expert/expertindex.html")




@login_required(login_url='/')
def manage_data_set(request):
    ob=database_table.objects.all()
    return render(request,"expert/manage data set.html", {'val': ob})



@login_required(login_url='/')
def manage_tips(request):
    ob=tips_table.objects.all()
    return render(request,"expert/manage tips.html",{'val':ob})

@login_required(login_url='/')
def addtipspost(request):
    tips=request.POST['textfield']
    details=request.POST['textfield2']
    ob=tips_table()
    ob.tips=tips
    ob.details=details
    ob. EXPERT=expert_table.objects.get(LOGIN_id=request.session['lid'])
    ob.save()
    return HttpResponse('''<script>alert("Add Success");window.location="/manage_tips#about"</script>''')



@login_required(login_url='/')
def send_doubtreply(request):
    return render(request,"expert/send doubtreply.html")


@login_required(login_url='/')
def view_doubt(request):
    ob=doubts_table.objects.filter(EXPERT__LOGIN__id=request.session['lid'])
    return render(request,"expert/view doubt.html",{'val':ob})




@login_required(login_url='/')
def ask_doubt_sp_post(request):
    ex=request.POST['select']
    Doubts=request.POST['textfield2']
    ob=doubts_table()
    ob.LOGIN=login_table.objects.get(id=request.session['lid'])
    ob.EXPERT=expert_table.objects.get(id=ex)
    ob.doubts=Doubts
    ob.date=datetime.datetime.now()
    ob.reply="pending"
    ob.save()
    return HttpResponse('''<script>alert("Add Success");window.location="/view_doubt1#about"</script>''')




@login_required(login_url='/')
def ask_doubt_sp(request):
    ob=expert_table.objects.all()
    return render(request,"service provider/ask doubt sp.html",{'val':ob})



@login_required(login_url='/')
def manage_sservice(request):
    ob=services_table.objects.filter(SERVICE_CENTER__LOGIN__id=request.session['lid'])
    return render(request,"service provider/manage sservice.html",{'val':ob})

@login_required(login_url='/')
def add_service(request):
    return render(request,"service provider/add service.html")



@login_required(login_url='/')
def addservicepost(request):
    service_name=request.POST['textfield']
    details=request.POST['textfield2']

    ob=services_table()
    ob.service_name=service_name
    ob.details=details
    ob.SERVICE_CENTER=service_center_table.objects.get(LOGIN__id=request.session['lid'])

    ob.save()
    return HttpResponse('''<script>alert("Add Success");window.location="/manage_sservice#about"</script>''')



@login_required(login_url='/')
def editservice(request,id):
    ob=services_table.objects.get(id=id)
    request.session['ES_id']=id
    return render(request,"service provider/editservice.html",{'val':ob})



@login_required(login_url='/')
def editservicepost(request):
    service_name=request.POST['textfield']
    details=request.POST['textfield2']

    ob=services_table.objects.get(id=request.session['ES_id'])
    ob.service_name=service_name
    ob.details=details

    ob.save()
    return HttpResponse('''<script>alert("Edited Success");window.location="/manage_sservice#about"</script>''')

@login_required(login_url='/')
def delete_service(request, id):
    ob=services_table.objects.get(id=id)
    ob.delete()
    return HttpResponse('''<script>alert("Deleted");window.location="/manage_sservice#about"</script>''')


@login_required(login_url='/')
def accept_request(request, id):
    ob=service_request_table.objects.get(id=id)
    ob.status='Accepted'
    ob.save()
    return HttpResponse('''<script>alert("Accepted");window.location="/verify_request_sp#about"</script>''')


@login_required(login_url='/')
def reject_request(request, id):
    ob=service_request_table.objects.get(id=id)
    ob.status='Rejected'
    ob.save()
    return HttpResponse('''<script>alert("Rejected");window.location="/verify_request_sp#about"</script>''')





@login_required(login_url='/')
def service_home(request):
    return render(request,"service provider/serviceindex.html")



@login_required(login_url='/')
def sp_login(request):
    return render(request,"service provider/sp login.html")




def sp_registeration(request):
    return render(request,"registrationindex.html")

def sp_registeration_post(request):
    name=request.POST['textfield']
    Place=request.POST['textfield2']
    Details=request.POST['textfield3']
    Email=request.POST['textfield4']
    Phone=request.POST['Email']
    photo=request.FILES['file']
    fs=FileSystemStorage()
    fsave=fs.save(photo.name,photo)
    Username=request.POST['textfield5']
    Password=request.POST['textfield6']
    lat=request.POST["lat"]
    lon=request.POST["lon"]

    ob=login_table()
    ob.username=Username
    ob.password=Password
    ob.type='pending'
    ob.save()

    on=service_center_table()
    on.LOGIN=ob
    on.name=name
    on.place=Place
    on.details=Details
    on.email=Email
    on.phone=Phone
    on.photo=fsave
    on.lati=lat
    on.longi=lon
    on.save()
    return HttpResponse('''<script>alert("Registered");window.location="/#about"</script>''')





@login_required(login_url='/')
def verify_request_sp(request):
    ob=service_request_table.objects.filter(SERVICE_CENTER__SERVICE_CENTER__LOGIN__id=request.session['lid'])
    return render(request,"service provider/verify request sp.html",{'val':ob})


@login_required(login_url='/')
def view_doubt_reply_sp(request):
    ob=doubts_table.objects.filter()
    return render(request,"service provider/view doubt reply sp.html",{'val':ob})




@login_required(login_url='/')
def view_doubt1(request):
    ob=doubts_table.objects.filter(LOGIN__id=request.session['lid'])
    return render(request,"service provider/view doubt.html",{'val':ob})

@login_required(login_url='/')
def view_doubt1_search(request):
    date=request.POST['textfield']
    ob=doubts_table.objects.filter(LOGIN__id=request.session['lid'],date=date)
    return render(request,"service provider/view doubt.html",{'val':ob})


@login_required(login_url='/')
def view_more_sp(request,id,date):
    # ob=payment_table.objects.get(id=id)
    ob = bill_table.objects.filter(date=date, status='paid',
                                   request_id__SERVICE_CENTER__SERVICE_CENTER__LOGIN__id=request.session['lid'],
                                   request_id__USER__id=id)

    return render(request,"service provider/view more sp.html",{'val':ob})


@login_required(login_url='/')
def view_payment_history(request):

    oj=bill_table.objects.filter(request_id__SERVICE_CENTER__SERVICE_CENTER__LOGIN__id=request.session['lid'],status='paid').order_by('date')
    rids=[]
    for i in oj:
        rids.append(i.request_id.id)

    ob=service_request_table.objects.filter(id__in=rids)
    datelist=[]
    for i in oj:
        if i.date not in datelist:
            datelist.append(i.date)
    result=[]
    for i in datelist:
        oj = bill_table.objects.filter(
            request_id__SERVICE_CENTER__SERVICE_CENTER__LOGIN__id=request.session['lid'], status='paid',date=i).order_by(
            'date')
        rids = []
        for j in oj:
            rids.append(j.request_id.id)

        ob = service_request_table.objects.filter(id__in=rids)
        userlist=[]
        for j in ob:
            if j.USER.id not in userlist:
                userlist.append(j.USER.id)
        for j in userlist:
            ob=bill_table.objects.filter(date=i,status='paid',request_id__SERVICE_CENTER__SERVICE_CENTER__LOGIN__id=request.session['lid'],request_id__USER__id=j)
            amt=0
            for k in ob:
                amt=amt+int(k.amount)
            r={"date":str(i),"amt":amt,"uname":ob[0].request_id.USER.name,"uid":ob[0].request_id.USER.id}
            result.append(r)

    # ob=payment_table.objects.filter(BILL__request_id__SERVICE_CENTER__SERVICE_CENTER__LOGIN__id=request.session['lid'],status='paid')
    # for i in ob:

    return render(request,"service provider/view payment history.html",{'val':result})

@login_required(login_url='/')
def update_amount(request):
    ob = service_request_table.objects.filter(SERVICE_CENTER__SERVICE_CENTER__LOGIN__id=request.session['lid'],status="Accepted")
    data=[]
    for i in ob:
        oo=bill_table.objects.filter(request_id=i.id)
        if len(oo)>0:
            row={"id":i.id,"username":oo[0].request_id.USER.name,"service":oo[0].request_id.SERVICE_CENTER.service_name,"status":str(oo[0].amount) +" "+oo[0].status,"date":i.date}
            data.append(row)
        else:
            row = {"id": i.id, "username": i.USER.name, "service": i.SERVICE_CENTER.service_name,
                   "status": "no","date":i.date}
            data.append(row)


    return render(request,"service provider/update amount.html",{'val':data})

@login_required(login_url='/')
def update(request,id):
    request.session['reqid']=id
    ob=bill_table.objects.filter(request_id=id)
    if len(ob) == 0:
        return render(request,"service provider/update.html")
    else:
        return HttpResponse('''<script>alert("Already Updated");window.location="/update_amount#about"</script>''')


@login_required(login_url='/')
def updt_amnt(request):
    amnt=request.POST['textfield']
    ob=bill_table()
    ob.amount=amnt
    ob.date=datetime.datetime.now()
    ob.status="pending"
    ob.request_id=service_request_table.objects.get(id=request.session['reqid'])
    ob.save()
    return HttpResponse('''<script>alert("Updated");window.location="/update_amount#about"</script>''')



#________________user


def login_code(request):
    print
    username = request.POST['uname']
    password = request.POST['pass']
    try:
        users = login_table.objects.get(username=username, password=password,type="user")
        if users is None:
            data = {"task": "invalid"}
            r = json.dumps(data)
            return HttpResponse(r)

        else:
            data = {"task": "valid", "id": users.id}
            r = json.dumps(data)
            return HttpResponse(r)
    except:
        data = {"task": "invalid"}
        r = json.dumps(data)
        print(r)
        return HttpResponse(r)


def registration(request):
    firstname = request.POST['Firstname']
    place = request.POST['Place']
    post_office = request.POST['Post']
    pin_code = request.POST['Pin']
    phone = request.POST['Phone']
    email_id = request.POST['Email']
    username = request.POST['Username']
    password = request.POST['Password']

    lob = login_table()
    lob.username = username
    lob.password = password
    lob.type = 'user'
    lob.save()

    user_obj = user_table()
    user_obj.name = firstname
    user_obj.place = place
    user_obj.post = post_office
    user_obj.pin = pin_code
    user_obj.phone = phone
    user_obj.email = email_id
    user_obj.LOGIN = lob
    user_obj.save()
    data = {"task": "valid"}
    r = json.dumps(data)
    return HttpResponse(r)

def feedback_app(request):
    feedback = request.POST["Feedback"]
    rating = request.POST["rating"]
    uid = request.POST["lid"]
    feedback_obj = feedback_table()
    feedback_obj.feedback = feedback
    feedback_obj.rating = rating
    feedback_obj.date = datetime.datetime.now()
    feedback_obj.USER = user_table.objects.get(LOGIN__id=uid)
    feedback_obj.save()
    data = {'task': "success"}
    r = json.dumps(data)
    return HttpResponse(r)


def view_feedback_app(request):
    lid = request.POST["lid"]
    ob=feedback_table.objects.filter(USER__LOGIN_id=lid).order_by('-id')
    data=[]
    for i in ob:
        row={"id":i.id,"feedback":i.feedback,"date":str(i.date),"rating":i.rating,"username":i.USER.name,"userplace":i.USER.place,"userpost":i.USER.post,"userpin":i.USER.pin,"useremail":i.USER.email,"userphone":i.USER.phone}
        data.append(row)
    r=json.dumps(data)
    return HttpResponse(r)

def send_complaint_app(request):
    print(request.POST)
    complaints = request.POST["Complaint"]
    u_id = request.POST["uid"]
    date = datetime.datetime.now()
    reply = "pending"
    complaint_obj = complaint_table()
    complaint_obj.complaint = complaints
    complaint_obj.date = date
    complaint_obj.reply = reply
    complaint_obj.USER = user_table.objects.get(LOGIN_id=u_id)
    complaint_obj.save()
    data = {'task': 'success'}
    r = json.dumps(data)
    return HttpResponse(r)


def view_complaint_app(request):
    lid=request.POST["lid"]
    ob=complaint_table.objects.filter(USER__LOGIN_id=lid).order_by('-id')
    data=[]
    for i in ob:
        row={"id":i.id,"complaint":i.complaint,"date":str(i.date),"reply":i.reply,"username":i.USER.name,"userplace":i.USER.place,"userpost":i.USER.post,"userpin":i.USER.pin,"useremail":i.USER.email,"userphone":i.USER.phone }
        data.append(row)
    r=json.dumps(data)
    return HttpResponse(r)

def ask_doubt_app(request):
    doubts = request.POST["Doubts"]
    u_id = request.POST["uid"]
    e_id = request.POST["expertid"]
    date = datetime.datetime.now()
    reply = "pending"
    doubts_obj = doubts_table()
    doubts_obj.doubts = doubts
    doubts_obj.date = date
    doubts_obj.reply = reply
    doubts_obj.LOGIN = login_table.objects.get(id=u_id)
    doubts_obj.EXPERT=expert_table.objects.get(id=e_id)

    doubts_obj.save()
    data = {'task': 'success'}
    r = json.dumps(data)
    return HttpResponse(r)


def view_reply_app(request):
    lid=request.POST["lid"]
    expertid=request.POST["expertid"]
    ob=doubts_table.objects.filter(LOGIN=lid,EXPERT=expertid).order_by('-id')
    data=[]
    for i in ob:
        row={"id":i.id,"doubts":i.doubts,"date":str(i.date),"reply":i.reply,"username":i.LOGIN.username,"password":i.LOGIN.password,"type":i.LOGIN.type,"expertname":i.EXPERT.name,"expertplace":i.EXPERT.place,"expertpost":i.EXPERT.post,"expertpin":i.EXPERT.pin,"expertemail":i.EXPERT.email,"expertphone":i.EXPERT.phone}
        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)

def view_service_center(request):
    from math import sin, cos, sqrt, atan2, radians
    print(request.POST, "kkkkkkkkkkk")
    lat1 = float(request.POST.get('lat', 0.0))
    lon1 = float(request.POST.get('long', 0.0))
    lat1 = radians(lat1)
    lon1 = radians(lon1)
    ob = service_center_table.objects.all()

    # print(request ,session['cid'],"mmmmmmmmm")
    data = []
    for i in ob:
        print("--",i.lati,"--",i.longi)
        lat2 = i.lati
        lon2 = i.longi

        # Convert latitude and longitude to radians if they are in degrees

        lat2 = radians(lat2)
        lon2 = radians(lon2)

        dlon = lon2 - lon1
        dlat = lat2 - lat1

        a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
        a = min(1.0, a)  # Ensure 'a' is not greater than 1 to avoid math domain error
        c = 2 * atan2(sqrt(a), sqrt(1 - a))

        # Approximate radius of the Earth in kilometers
        R = 6373.0
        distance = R * c
        print(distance, "==================================")
        if distance < 1000:

                row = {"id": i.id, "centername": i.name,
                       "centerplace": i.place, "centerdetails": i.details,
                       "centeremail": i.email, "centerphone": i.phone,
                       "centerphoto": str(i.photo.url)}
                data.append(row)
    r = json.dumps(data)
    print("------------",data)
    return HttpResponse(r)
def view_servicecenter_app_search(request):
    name=request.POST["name"]
    ob = service_center_table.objects.filter(name__contains=name)
    data = []
    for i in ob:
        row = {"id": i.id, "centername": i.name,
               "centerplace": i.place, "centerdetails": i.details,
               "centeremail": i.email, "centerphone": i.phone,
               "centerphoto": str(i.photo.url)}

        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)
def view_service_app(request):
    service_centerid=request.POST["service_centerid"]
    ob=services_table.objects.filter(SERVICE_CENTER=service_centerid)
    data=[]
    for i in ob:
        row={"id":i.id,"serc_name":i.service_name,"details":i.details}

        data.append(row)
    r=json.dumps(data)
    return HttpResponse(r)


def view_service_app_search(request):
    service_centerid = request.POST["service_centerid"]
    name=request.POST["name"]
    ob=services_table.objects.filter(service_name__contains=name,SERVICE_CENTER=service_centerid)
    data=[]
    for i in ob:
        row={"id":i.id,"serc_name":i.service_name,"details":i.details}

        data.append(row)
    r=json.dumps(data)
    return HttpResponse(r)



def view_tips_app(request):
    ob=tips_table.objects.all()
    data=[]
    for i in ob:
        row={"id":i.id,"tips":i.tips,"details":i.details,"expertname":i.EXPERT.name,"expertplace":i.EXPERT.place,"expertpost":i.EXPERT.post,"expertpin":i.EXPERT.pin,"expertemail":i.EXPERT.email,"expertphone":i.EXPERT.phone}
        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)


def view_tips_app_search(request):
    name=request.POST["name"]
    ob=tips_table.objects.filter(tips__contains=name)
    data=[]
    for i in ob:
        row={"id":i.id,"tips":i.tips,"details":i.details,"expertname":i.EXPERT.name,"expertplace":i.EXPERT.place,"expertpost":i.EXPERT.post,"expertpin":i.EXPERT.pin,"expertemail":i.EXPERT.email,"expertphone":i.EXPERT.phone}
        data.append(row)
    r = json.dumps(data)
    return HttpResponse(r)

def view_expert_app(request):
    ob=expert_table.objects.all()
    data=[]
    for i in ob:
        row={"id":i.id,"expname":i.name,"expplace":i.place,"expemail":i.email,"expphone":i.phone}
        data.append(row)
    r=json.dumps(data)
    return HttpResponse(r)


def view_expert_app_search(request):
    name=request.POST["name"]
    ob=expert_table.objects.filter(name__contains=name)
    data=[]
    for i in ob:
        row={"id":i.id,"expname":i.name,"expplace":i.place,"expemail":i.email,"expphone":i.phone}
        data.append(row)
    r=json.dumps(data)
    return HttpResponse(r)







import datetime
def service_req_app(request):
    service_id = request.POST["serviceid"]
    requestt = request.POST["Request"]
    u_id = request.POST["uid"]
    date = datetime.datetime.now()
    status = "Pending"
    service_req_obj = service_request_table()
    service_req_obj.SERVICE_CENTER = services_table.objects.get(id=service_id)
    service_req_obj.date = date
    service_req_obj.status = status
    service_req_obj.USER = user_table.objects.get(LOGIN=u_id)
    service_req_obj.request=requestt
    service_req_obj.save()
    data = {'task': 'success'}
    r = json.dumps(data)
    return HttpResponse(r)

def view_service_req_app(request):
    lid=request.POST["lid"]
    ob=service_request_table.objects.filter(USER__LOGIN_id=lid).order_by('-id')
    data=[]
    for i in ob:
        row={"id":i.id,"usrname":i.USER.name,"usrplace":i.USER.place,"usrpost":i.USER.post,"usrpin":i.USER.pin,
             "usremail":i.USER.email,"usrphone":i.USER.phone,"servicename":i.SERVICE_CENTER.service_name,
             "servicedetails":i.SERVICE_CENTER.details,"req":i.request,"stat":i.status,"date":str(i.date),
             "centername":i.SERVICE_CENTER.SERVICE_CENTER.name,"Lid":i.SERVICE_CENTER.SERVICE_CENTER.LOGIN.id,"centerPhone":i.SERVICE_CENTER.SERVICE_CENTER.phone}
        data.append(row)
    r=json.dumps(data)
    return HttpResponse(r)

from .chatbot import chatbot_main
def in_message2(request):

    fromid = request.POST['fid']

    message=request.POST['msg']
    ans=chatbot_main(message)
    ob=chat_bot()
    ob.USER=user_table.objects.get(LOGIN__id=fromid)
    ob.question=message
    ob.answer=ans
    ob.Date=datetime.datetime.today()
    ob.save()

    return JsonResponse({"status":'send'})

def view_message2(request):
    print("wwwwwwwwwwwwwwww")
    print(request.POST)
    fromid=request.POST['fid']

    lmid = request.POST['lastmsgid']
    ob=chat_bot.objects.filter(USER__LOGIN__id=fromid,id__gt=lmid)
    res=[]
    for i in ob:
        r={"date":str(i.Date),"message":i.question,"fromid":i.USER.LOGIN.id,"msgid":i.id}
        res.append(r)
        r={"date":str(i.Date),"message":i.answer,"fromid":'0',"msgid":i.id}
        res.append(r)


    if len(res)>0:
        return JsonResponse({'status':'ok', 'res1':res})
    else:
        return JsonResponse({'status':'not found'})


def payment(request):
    rid=request.POST["bid"]
    lid=request.POST["lid"]
    am=request.POST["amt"]

    print(lid,rid,am)

    ob2=service_request_table.objects.get(id=rid)
    ob2.status="paid"
    ob2.save()

    ob=bill_table.objects.get(request_id=rid)
    ob.date=datetime.datetime.now()
    ob.status="paid"
    ob.save()
    print("=================================")

    bb=payment_table()
    bb.USER=user_table.objects.get(LOGIN__id=lid)
    bb.BILL_id=ob.id
    bb.amount=am
    bb.date=datetime.datetime.now()
    bb.status="paid"
    bb.save()

    data = {'task': 'success'}
    r = json.dumps(data)
    return HttpResponse(r)


def view_bill(request):
    rid=request.POST["rid"]
    ob=bill_table.objects.filter(request_id=rid)
    if len(ob)>0:
        data={"task":"valid","amount":ob[0].amount}
    else:
        data = {"task": "invalid"}

    r=json.dumps(data)
    return HttpResponse(r)

