/*
SQLyog Community v13.0.1 (64 bit)
MySQL - 8.0.33 : Database - service
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`service` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `service`;

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_group` */

/*Table structure for table `auth_group_permissions` */

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_group_permissions` */

/*Table structure for table `auth_permission` */

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_permission` */

insert  into `auth_permission`(`id`,`name`,`content_type_id`,`codename`) values 
(1,'Can add permission',1,'add_permission'),
(2,'Can change permission',1,'change_permission'),
(3,'Can delete permission',1,'delete_permission'),
(4,'Can view permission',1,'view_permission'),
(5,'Can add group',2,'add_group'),
(6,'Can change group',2,'change_group'),
(7,'Can delete group',2,'delete_group'),
(8,'Can view group',2,'view_group'),
(9,'Can add user',3,'add_user'),
(10,'Can change user',3,'change_user'),
(11,'Can delete user',3,'delete_user'),
(12,'Can view user',3,'view_user'),
(13,'Can add content type',4,'add_contenttype'),
(14,'Can change content type',4,'change_contenttype'),
(15,'Can delete content type',4,'delete_contenttype'),
(16,'Can view content type',4,'view_contenttype'),
(17,'Can add session',5,'add_session'),
(18,'Can change session',5,'change_session'),
(19,'Can delete session',5,'delete_session'),
(20,'Can view session',5,'view_session'),
(21,'Can add bill_table',6,'add_bill_table'),
(22,'Can change bill_table',6,'change_bill_table'),
(23,'Can delete bill_table',6,'delete_bill_table'),
(24,'Can view bill_table',6,'view_bill_table'),
(25,'Can add database_table',7,'add_database_table'),
(26,'Can change database_table',7,'change_database_table'),
(27,'Can delete database_table',7,'delete_database_table'),
(28,'Can view database_table',7,'view_database_table'),
(29,'Can add expert_table',8,'add_expert_table'),
(30,'Can change expert_table',8,'change_expert_table'),
(31,'Can delete expert_table',8,'delete_expert_table'),
(32,'Can view expert_table',8,'view_expert_table'),
(33,'Can add login_table',9,'add_login_table'),
(34,'Can change login_table',9,'change_login_table'),
(35,'Can delete login_table',9,'delete_login_table'),
(36,'Can view login_table',9,'view_login_table'),
(37,'Can add service_center_table',10,'add_service_center_table'),
(38,'Can change service_center_table',10,'change_service_center_table'),
(39,'Can delete service_center_table',10,'delete_service_center_table'),
(40,'Can view service_center_table',10,'view_service_center_table'),
(41,'Can add user_table',11,'add_user_table'),
(42,'Can change user_table',11,'change_user_table'),
(43,'Can delete user_table',11,'delete_user_table'),
(44,'Can view user_table',11,'view_user_table'),
(45,'Can add tips_table',12,'add_tips_table'),
(46,'Can change tips_table',12,'change_tips_table'),
(47,'Can delete tips_table',12,'delete_tips_table'),
(48,'Can view tips_table',12,'view_tips_table'),
(49,'Can add services_table',13,'add_services_table'),
(50,'Can change services_table',13,'change_services_table'),
(51,'Can delete services_table',13,'delete_services_table'),
(52,'Can view services_table',13,'view_services_table'),
(53,'Can add service_request_table',14,'add_service_request_table'),
(54,'Can change service_request_table',14,'change_service_request_table'),
(55,'Can delete service_request_table',14,'delete_service_request_table'),
(56,'Can view service_request_table',14,'view_service_request_table'),
(57,'Can add payment_table',15,'add_payment_table'),
(58,'Can change payment_table',15,'change_payment_table'),
(59,'Can delete payment_table',15,'delete_payment_table'),
(60,'Can view payment_table',15,'view_payment_table'),
(61,'Can add feedback_table',16,'add_feedback_table'),
(62,'Can change feedback_table',16,'change_feedback_table'),
(63,'Can delete feedback_table',16,'delete_feedback_table'),
(64,'Can view feedback_table',16,'view_feedback_table'),
(65,'Can add doubts_table',17,'add_doubts_table'),
(66,'Can change doubts_table',17,'change_doubts_table'),
(67,'Can delete doubts_table',17,'delete_doubts_table'),
(68,'Can view doubts_table',17,'view_doubts_table'),
(69,'Can add complaint_table',18,'add_complaint_table'),
(70,'Can change complaint_table',18,'change_complaint_table'),
(71,'Can delete complaint_table',18,'delete_complaint_table'),
(72,'Can view complaint_table',18,'view_complaint_table'),
(73,'Can add chat_bot',19,'add_chat_bot'),
(74,'Can change chat_bot',19,'change_chat_bot'),
(75,'Can delete chat_bot',19,'delete_chat_bot'),
(76,'Can view chat_bot',19,'view_chat_bot');

/*Table structure for table `auth_user` */

DROP TABLE IF EXISTS `auth_user`;

CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user` */

insert  into `auth_user`(`id`,`password`,`last_login`,`is_superuser`,`username`,`first_name`,`last_name`,`email`,`is_staff`,`is_active`,`date_joined`) values 
(1,'pbkdf2_sha256$260000$2mZWfvTzmcoK5JOR2AfNvi$ZJoYr3roNIbBEQViU9BK/7PSHJAThTCal/ZyL8Pobzo=','2024-02-26 15:58:41.683791',1,'admin','','','admin@gmail.com',1,1,'2024-02-26 14:51:42.692011');

/*Table structure for table `auth_user_groups` */

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user_groups` */

/*Table structure for table `auth_user_user_permissions` */

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `auth_user_user_permissions` */

/*Table structure for table `django_content_type` */

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_content_type` */

insert  into `django_content_type`(`id`,`app_label`,`model`) values 
(2,'auth','group'),
(1,'auth','permission'),
(3,'auth','user'),
(4,'contenttypes','contenttype'),
(6,'service_app','bill_table'),
(19,'service_app','chat_bot'),
(18,'service_app','complaint_table'),
(7,'service_app','database_table'),
(17,'service_app','doubts_table'),
(8,'service_app','expert_table'),
(16,'service_app','feedback_table'),
(9,'service_app','login_table'),
(15,'service_app','payment_table'),
(10,'service_app','service_center_table'),
(14,'service_app','service_request_table'),
(13,'service_app','services_table'),
(12,'service_app','tips_table'),
(11,'service_app','user_table'),
(5,'sessions','session');

/*Table structure for table `django_migrations` */

DROP TABLE IF EXISTS `django_migrations`;

CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_migrations` */

insert  into `django_migrations`(`id`,`app`,`name`,`applied`) values 
(1,'contenttypes','0001_initial','2024-02-26 14:46:44.443880'),
(2,'contenttypes','0002_remove_content_type_name','2024-02-26 14:46:44.536857'),
(3,'auth','0001_initial','2024-02-26 14:46:45.274102'),
(4,'auth','0002_alter_permission_name_max_length','2024-02-26 14:46:45.357152'),
(5,'auth','0003_alter_user_email_max_length','2024-02-26 14:46:45.392768'),
(6,'auth','0004_alter_user_username_opts','2024-02-26 14:46:45.409390'),
(7,'auth','0005_alter_user_last_login_null','2024-02-26 14:46:45.488276'),
(8,'auth','0006_require_contenttypes_0002','2024-02-26 14:46:45.493564'),
(9,'auth','0007_alter_validators_add_error_messages','2024-02-26 14:46:45.506873'),
(10,'auth','0008_alter_user_username_max_length','2024-02-26 14:46:45.587031'),
(11,'auth','0009_alter_user_last_name_max_length','2024-02-26 14:46:45.664579'),
(12,'auth','0010_alter_group_name_max_length','2024-02-26 14:46:45.694039'),
(13,'auth','0011_update_proxy_permissions','2024-02-26 14:46:45.709193'),
(14,'auth','0012_alter_user_first_name_max_length','2024-02-26 14:46:45.796665'),
(15,'service_app','0001_initial','2024-02-26 14:46:47.131699'),
(16,'sessions','0001_initial','2024-02-26 14:46:47.180867'),
(17,'service_app','0002_alter_chat_bot_answer','2024-02-26 16:16:06.185958');

/*Table structure for table `django_session` */

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `django_session` */

insert  into `django_session`(`session_key`,`session_data`,`expire_date`) values 
('7ue81a0kafsw0hgm93zsd2j1c88l9gib','.eJxVjr0OwjAQg98lcxVxaUNzjOw8Q3WXXEihNFJ_JsS700CXbpb92fJbDX1QF1OpjtYldessU1ccBergMfmnjCUIDxrvWfs8LlPPuiB6T2d9y0GG684eBhLNaWsbNCR1SyBtK0Z80yBbdGQsk40WHAI776W2IBEcYwgni2eJTJEc0jYaMv8uQqV8fv3l5wuuwEE8:1redNg:0-67qqQLWPaUxZx4ic_wI80r9XesmoWt8dGmkXy2vow','2024-03-11 15:59:04.429950');

/*Table structure for table `service_app_bill_table` */

DROP TABLE IF EXISTS `service_app_bill_table`;

CREATE TABLE `service_app_bill_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `amount` bigint NOT NULL,
  `date` date NOT NULL,
  `status` varchar(500) NOT NULL,
  `request_id_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_bill_tab_request_id_id_500fac1d_fk_service_a` (`request_id_id`),
  CONSTRAINT `service_app_bill_tab_request_id_id_500fac1d_fk_service_a` FOREIGN KEY (`request_id_id`) REFERENCES `service_app_service_request_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_bill_table` */

insert  into `service_app_bill_table`(`id`,`amount`,`date`,`status`,`request_id_id`) values 
(1,750,'2024-02-27','paid',1);

/*Table structure for table `service_app_chat_bot` */

DROP TABLE IF EXISTS `service_app_chat_bot`;

CREATE TABLE `service_app_chat_bot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `question` varchar(500) NOT NULL,
  `answer` varchar(1000) NOT NULL,
  `Date` date NOT NULL,
  `USER_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_chat_bot_USER_id_9b3d7fe8_fk_service_a` (`USER_id`),
  CONSTRAINT `service_app_chat_bot_USER_id_9b3d7fe8_fk_service_a` FOREIGN KEY (`USER_id`) REFERENCES `service_app_user_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_chat_bot` */

insert  into `service_app_chat_bot`(`id`,`question`,`answer`,`Date`,`USER_id`) values 
(1,'hlo','Hello! How can I help you today?','2024-02-26',1),
(2,'how are you','I\'m doing great, thank you! How can I assist you today?','2024-02-26',1),
(3,'my lap monitor is not working ','I\'m sorry to hear that your laptop monitor is not working. Is there anything specific you would like help with in trying to fix it?','2024-02-26',1),
(4,'what should I do','How about we work on a Python programming project together? What kind of project are you interested in?','2024-02-26',1),
(5,'error in openai module','I\'m sorry to hear that you are encountering an error with the OpenAI module. Can you please provide more details about the error message you are seeing? This will help me better understand the issue and provide you with a solution.','2024-02-26',1),
(6,'no module for openai','It seems like you are trying to use the OpenAI module in Python, but you are encountering an error saying that the module is not found. Make sure you have installed the OpenAI module by running the following command in your terminal:\n\n```\npip install openai\n```\n\nIf you continue to encounter issues, please let me know so I can assist you further.','2024-02-26',1),
(7,'ok thank you','You\'re welcome! If you have any questions about Python programming or anything else, feel free to ask.','2024-02-26',1);

/*Table structure for table `service_app_complaint_table` */

DROP TABLE IF EXISTS `service_app_complaint_table`;

CREATE TABLE `service_app_complaint_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `complaint` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `reply` varchar(100) NOT NULL,
  `USER_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_complain_USER_id_ff2e96d6_fk_service_a` (`USER_id`),
  CONSTRAINT `service_app_complain_USER_id_ff2e96d6_fk_service_a` FOREIGN KEY (`USER_id`) REFERENCES `service_app_user_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_complaint_table` */

insert  into `service_app_complaint_table`(`id`,`complaint`,`date`,`reply`,`USER_id`) values 
(1,'user complaints','2024-02-26','solved mmmmmmmmmm',1);

/*Table structure for table `service_app_database_table` */

DROP TABLE IF EXISTS `service_app_database_table`;

CREATE TABLE `service_app_database_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `question` varchar(500) NOT NULL,
  `answer` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_database_table` */

/*Table structure for table `service_app_doubts_table` */

DROP TABLE IF EXISTS `service_app_doubts_table`;

CREATE TABLE `service_app_doubts_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `doubts` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `reply` varchar(500) NOT NULL,
  `EXPERT_id` bigint NOT NULL,
  `LOGIN_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_doubts_t_EXPERT_id_ec405b4d_fk_service_a` (`EXPERT_id`),
  KEY `service_app_doubts_t_LOGIN_id_89bd6e33_fk_service_a` (`LOGIN_id`),
  CONSTRAINT `service_app_doubts_t_EXPERT_id_ec405b4d_fk_service_a` FOREIGN KEY (`EXPERT_id`) REFERENCES `service_app_expert_table` (`id`),
  CONSTRAINT `service_app_doubts_t_LOGIN_id_89bd6e33_fk_service_a` FOREIGN KEY (`LOGIN_id`) REFERENCES `service_app_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_doubts_table` */

insert  into `service_app_doubts_table`(`id`,`doubts`,`date`,`reply`,`EXPERT_id`,`LOGIN_id`) values 
(1,'I have doubt about the storage','2024-02-26','xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',1,4),
(2,'servide provider doubt','2024-02-26','pending',1,3),
(3,'user doubt','2024-02-26','pending',1,4);

/*Table structure for table `service_app_expert_table` */

DROP TABLE IF EXISTS `service_app_expert_table`;

CREATE TABLE `service_app_expert_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` bigint NOT NULL,
  `email` varchar(254) NOT NULL,
  `phone` bigint NOT NULL,
  `LOGIN_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_expert_t_LOGIN_id_afb61bbc_fk_service_a` (`LOGIN_id`),
  CONSTRAINT `service_app_expert_t_LOGIN_id_afb61bbc_fk_service_a` FOREIGN KEY (`LOGIN_id`) REFERENCES `service_app_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_expert_table` */

insert  into `service_app_expert_table`(`id`,`name`,`place`,`post`,`pin`,`email`,`phone`,`LOGIN_id`) values 
(1,'expertone','vatakara','vatakarapost',675448,'ex12@g.c',9878675645,2);

/*Table structure for table `service_app_feedback_table` */

DROP TABLE IF EXISTS `service_app_feedback_table`;

CREATE TABLE `service_app_feedback_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `rating` double NOT NULL,
  `USER_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_feedback_USER_id_98c17936_fk_service_a` (`USER_id`),
  CONSTRAINT `service_app_feedback_USER_id_98c17936_fk_service_a` FOREIGN KEY (`USER_id`) REFERENCES `service_app_user_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_feedback_table` */

insert  into `service_app_feedback_table`(`id`,`feedback`,`date`,`rating`,`USER_id`) values 
(1,'5ttttttttt','2024-02-26',3.5,1);

/*Table structure for table `service_app_login_table` */

DROP TABLE IF EXISTS `service_app_login_table`;

CREATE TABLE `service_app_login_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_login_table` */

insert  into `service_app_login_table`(`id`,`username`,`password`,`type`) values 
(1,'admin','admin','admin'),
(2,'expone','ex@123','expert'),
(3,'serv','serve@123','service provider'),
(4,'bin','123','user');

/*Table structure for table `service_app_payment_table` */

DROP TABLE IF EXISTS `service_app_payment_table`;

CREATE TABLE `service_app_payment_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `amount` bigint NOT NULL,
  `date` date NOT NULL,
  `status` varchar(500) NOT NULL,
  `BILL_id` bigint NOT NULL,
  `USER_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_payment__BILL_id_7156d7c2_fk_service_a` (`BILL_id`),
  KEY `service_app_payment__USER_id_74ff0f3a_fk_service_a` (`USER_id`),
  CONSTRAINT `service_app_payment__BILL_id_7156d7c2_fk_service_a` FOREIGN KEY (`BILL_id`) REFERENCES `service_app_bill_table` (`id`),
  CONSTRAINT `service_app_payment__USER_id_74ff0f3a_fk_service_a` FOREIGN KEY (`USER_id`) REFERENCES `service_app_user_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_payment_table` */

insert  into `service_app_payment_table`(`id`,`amount`,`date`,`status`,`BILL_id`,`USER_id`) values 
(1,750,'2024-02-27','paid',1,1);

/*Table structure for table `service_app_service_center_table` */

DROP TABLE IF EXISTS `service_app_service_center_table`;

CREATE TABLE `service_app_service_center_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `details` varchar(500) NOT NULL,
  `email` varchar(254) NOT NULL,
  `phone` bigint NOT NULL,
  `photo` varchar(100) NOT NULL,
  `lati` double NOT NULL,
  `longi` double NOT NULL,
  `LOGIN_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_service__LOGIN_id_1d387e94_fk_service_a` (`LOGIN_id`),
  CONSTRAINT `service_app_service__LOGIN_id_1d387e94_fk_service_a` FOREIGN KEY (`LOGIN_id`) REFERENCES `service_app_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_service_center_table` */

insert  into `service_app_service_center_table`(`id`,`name`,`place`,`details`,`email`,`phone`,`photo`,`lati`,`longi`,`LOGIN_id`) values 
(1,'servicepro','calicut','westhill calicut','b@g.c',9999997877,'WhatsApp Image 2024-02-05 at 11.36.41 PM.jpeg',11.2962,75.7744,3);

/*Table structure for table `service_app_service_request_table` */

DROP TABLE IF EXISTS `service_app_service_request_table`;

CREATE TABLE `service_app_service_request_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `request` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `SERVICE_CENTER_id` bigint NOT NULL,
  `USER_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_service__SERVICE_CENTER_id_dd5fb554_fk_service_a` (`SERVICE_CENTER_id`),
  KEY `service_app_service__USER_id_3a484889_fk_service_a` (`USER_id`),
  CONSTRAINT `service_app_service__SERVICE_CENTER_id_dd5fb554_fk_service_a` FOREIGN KEY (`SERVICE_CENTER_id`) REFERENCES `service_app_services_table` (`id`),
  CONSTRAINT `service_app_service__USER_id_3a484889_fk_service_a` FOREIGN KEY (`USER_id`) REFERENCES `service_app_user_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_service_request_table` */

insert  into `service_app_service_request_table`(`id`,`request`,`status`,`date`,`SERVICE_CENTER_id`,`USER_id`) values 
(1,'keyboard and monitor problm','paid','2024-02-26',1,1),
(2,'gggg','Pending','2024-02-27',1,1);

/*Table structure for table `service_app_services_table` */

DROP TABLE IF EXISTS `service_app_services_table`;

CREATE TABLE `service_app_services_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `service_name` varchar(500) NOT NULL,
  `details` varchar(500) NOT NULL,
  `SERVICE_CENTER_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_services_SERVICE_CENTER_id_3c7f89c5_fk_service_a` (`SERVICE_CENTER_id`),
  CONSTRAINT `service_app_services_SERVICE_CENTER_id_3c7f89c5_fk_service_a` FOREIGN KEY (`SERVICE_CENTER_id`) REFERENCES `service_app_service_center_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_services_table` */

insert  into `service_app_services_table`(`id`,`service_name`,`details`,`SERVICE_CENTER_id`) values 
(1,'lapservice','xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',1),
(2,'repaire','\r\n          yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy',1);

/*Table structure for table `service_app_tips_table` */

DROP TABLE IF EXISTS `service_app_tips_table`;

CREATE TABLE `service_app_tips_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tips` varchar(500) NOT NULL,
  `details` varchar(500) NOT NULL,
  `EXPERT_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_tips_tab_EXPERT_id_ee908dcb_fk_service_a` (`EXPERT_id`),
  CONSTRAINT `service_app_tips_tab_EXPERT_id_ee908dcb_fk_service_a` FOREIGN KEY (`EXPERT_id`) REFERENCES `service_app_expert_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_tips_table` */

insert  into `service_app_tips_table`(`id`,`tips`,`details`,`EXPERT_id`) values 
(1,'tipone','xxxxxxxxxxxxxxxxxx',1);

/*Table structure for table `service_app_user_table` */

DROP TABLE IF EXISTS `service_app_user_table`;

CREATE TABLE `service_app_user_table` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` bigint NOT NULL,
  `email` varchar(254) NOT NULL,
  `phone` bigint NOT NULL,
  `LOGIN_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_app_user_tab_LOGIN_id_f14cc0b4_fk_service_a` (`LOGIN_id`),
  CONSTRAINT `service_app_user_tab_LOGIN_id_f14cc0b4_fk_service_a` FOREIGN KEY (`LOGIN_id`) REFERENCES `service_app_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `service_app_user_table` */

insert  into `service_app_user_table`(`id`,`name`,`place`,`post`,`pin`,`email`,`phone`,`LOGIN_id`) values 
(1,'Bindhiya ','p','westhill',674899,'b@g.c',9757464333,4);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
